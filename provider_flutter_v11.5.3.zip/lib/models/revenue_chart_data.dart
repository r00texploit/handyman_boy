class RevenueChartData {
  final String month;
  final double? revenue;

  RevenueChartData({required this.month, this.revenue});
}
