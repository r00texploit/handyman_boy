class VisitTypeData {
  String? title;
  String? key;
  bool? isEnabled;

  VisitTypeData({this.title, this.isEnabled, this.key});
}
